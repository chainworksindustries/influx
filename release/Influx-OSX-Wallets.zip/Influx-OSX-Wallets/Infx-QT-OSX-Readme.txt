
##Influx-QT for OSX Readme##

If you are using an older generation of OSX Pre 2011 please run 
Influx-Qt-2-2010-Older
-------------------------------------------------------------------

If you are using a newer generation of OSX 2011 and above please run 
Influx-Qt-4-2011+
-------------------------------------------------------------------

Copyright @2015 Influxcoin.xyz (INFX) 

If you need help please contact us at: 
Website: www.influxcoin.xyz
Email: info@influxcoin.xyz
IRC: irc.freenode.net - #influxcoin
Twitter: @Infxcoin
